from . import prefs
from . import properties
from . import operators
from . import panels
from . import validation
from .mesh_check.overlay import MeshCheck, MeshCheckGPU


def register():
    prefs.register()
    properties.register()
    operators.register()
    validation.register()
    panels.register()


def unregister():
    # Tear down live GPU / depsgraph handlers first so a reload never leaves an
    # orphaned overlay firing against unregistered properties.
    MeshCheckGPU.remove_handler()
    MeshCheck.remove_callback()

    panels.unregister()
    validation.unregister()
    operators.unregister()
    properties.unregister()
    prefs.unregister()
