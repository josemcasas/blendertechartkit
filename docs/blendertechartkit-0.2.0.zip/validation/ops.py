import bpy

from . import checks


class TAKIT_OT_validate_all(bpy.types.Operator):
    bl_idname = "takit.validate_all"
    bl_label = "Validate for UE5"
    bl_description = "Run all asset checks on the selection (or whole scene if nothing is selected)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        failed = warned = 0
        for c in checks.get_checks():
            c.run(context)
            if c.state == checks.FAILED:
                failed += 1
            elif c.state == checks.WARNING:
                warned += 1

        if failed:
            self.report({'ERROR'}, f"Validation: {failed} failed, {warned} warnings")
        elif warned:
            self.report({'WARNING'}, f"Validation: {warned} warnings")
        else:
            self.report({'INFO'}, "Validation passed")
        return {'FINISHED'}


class TAKIT_OT_validate_select(bpy.types.Operator):
    bl_idname = "takit.validate_select"
    bl_label = "Select Errors"
    bl_description = "Select the objects/elements that failed this check"
    bl_options = {'REGISTER', 'UNDO'}

    check_id: bpy.props.StringProperty()

    def execute(self, context):
        c = checks.get_check(self.check_id)
        if c and not c.passed:
            c.select(context)
        return {'FINISHED'}


class TAKIT_OT_validate_fix(bpy.types.Operator):
    bl_idname = "takit.validate_fix"
    bl_label = "Fix"
    bl_description = "Auto-fix this check, then re-run it"
    bl_options = {'REGISTER', 'UNDO'}

    check_id: bpy.props.StringProperty()

    def execute(self, context):
        c = checks.get_check(self.check_id)
        if not c or c.passed:
            return {'CANCELLED'}
        c.fix(context)
        if c.can_retry_on_fix:
            c.run(context)
        self.report({'INFO'}, f"Fixed: {c.name}")
        return {'FINISHED'}


_classes = (
    TAKIT_OT_validate_all,
    TAKIT_OT_validate_select,
    TAKIT_OT_validate_fix,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
