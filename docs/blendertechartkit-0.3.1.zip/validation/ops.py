import bpy

from . import checks


class TAKIT_OT_validate_all(bpy.types.Operator):
    bl_idname = "takit.validate_all"
    bl_label = "Validate for UE5"
    bl_description = "Run all asset checks on the selection (or whole scene if nothing is selected)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        failed = warned = 0
        for c in checks.get_checks():
            c.run(context)
            if c.state == checks.FAILED:
                failed += 1
            elif c.state == checks.WARNING:
                warned += 1

        if failed:
            self.report({'ERROR'}, f"Validation: {failed} failed, {warned} warnings")
        elif warned:
            self.report({'WARNING'}, f"Validation: {warned} warnings")
        else:
            self.report({'INFO'}, "Validation passed")
        return {'FINISHED'}


class TAKIT_OT_validate_select(bpy.types.Operator):
    bl_idname = "takit.validate_select"
    bl_label = "Select Errors"
    bl_description = "Select the objects/elements that failed this check"
    bl_options = {'REGISTER', 'UNDO'}

    check_id: bpy.props.StringProperty()

    def execute(self, context):
        c = checks.get_check(self.check_id)
        if c and not c.passed:
            c.select(context)
        return {'FINISHED'}


class TAKIT_OT_validate_fix(bpy.types.Operator):
    bl_idname = "takit.validate_fix"
    bl_label = "Fix"
    bl_description = "Auto-fix this check, then re-run it"
    bl_options = {'REGISTER', 'UNDO'}

    check_id: bpy.props.StringProperty()

    def execute(self, context):
        c = checks.get_check(self.check_id)
        if not c or c.passed:
            return {'CANCELLED'}
        c.fix(context)
        if c.can_retry_on_fix:
            c.run(context)
        self.report({'INFO'}, f"Fixed: {c.name}")
        return {'FINISHED'}


class TAKIT_OT_validate_details(bpy.types.Operator):
    bl_idname = "takit.validate_details"
    bl_label = "Details"
    bl_description = "Show what this check found"

    check_id: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=340)

    def draw(self, context):
        layout = self.layout
        c = checks.get_check(self.check_id)
        if not c:
            return

        layout.label(text=c.name, icon=checks.STATE_ICON[c.state])
        col = layout.column(align=True)
        for line in _wrap(c.description, 46):
            col.label(text=line)

        if not c.completed:
            layout.label(text="Not run yet.", icon='INFO')
            return
        if c.passed:
            layout.label(text="Passed — nothing to report.", icon='CHECKMARK')
            return

        box = layout.box()
        box.label(text=f"{c.error_count} issue(s):")
        col = box.column(align=True)
        details = c.detail_lines()
        for line in details[:20]:
            col.label(text=line)
        if len(details) > 20:
            col.label(text=f"... and {len(details) - 20} more")

    def execute(self, context):
        return {'FINISHED'}


def _wrap(text, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines


_classes = (
    TAKIT_OT_validate_all,
    TAKIT_OT_validate_select,
    TAKIT_OT_validate_fix,
    TAKIT_OT_validate_details,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
