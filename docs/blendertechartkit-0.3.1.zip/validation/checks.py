"""Asset validation framework for UE5 export.

Ported in spirit from Chris Zurbrigg's Maya `cz_validation` (unittest-style
TestCase pattern) to Blender/bpy. Each check overrides execute() and returns
pass/fail; the base handles state, object/element selection and (optional) fix.

Add a check: subclass ValidationCheck, set the class attrs, implement execute()
(populate self.error_objects and/or self.error_elements, return bool), append it
to ALL_CHECKS.
"""
import re
import bpy
import bmesh

# Run states
NOT_RUN, PASSED, WARNING, FAILED = 'NOT_RUN', 'PASSED', 'WARNING', 'FAILED'

STATE_ICON = {
    NOT_RUN: 'RADIOBUT_OFF',
    PASSED: 'CHECKMARK',
    WARNING: 'ERROR',       # triangle
    FAILED: 'CANCEL',
}

_SUFFIX = re.compile(r'\.\d{3}$')


class ValidationCheck:
    id = "base"
    name = "Check"
    description = ""
    warn_on_fail = False     # WARNING (amber) vs FAILED (red)
    can_select = False
    can_fix = False
    can_retry_on_fix = False

    def __init__(self):
        self.reset()

    def reset(self):
        self.completed = False
        self.passed = False
        self.error_objects = []           # object names (object-level errors)
        self.error_elements = {}          # obj_name -> ('VERT'|'EDGE'|'FACE', [indices])

    # --- lifecycle ---
    def run(self, context):
        self.reset()
        self.passed = self.execute(context)
        self.completed = True
        return self.passed

    def execute(self, context):
        raise NotImplementedError

    def fix(self, context):
        pass

    # --- scope: selected meshes, or the whole scene if nothing is selected ---
    def targets(self, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        return sel or [o for o in context.scene.objects if o.type == 'MESH']

    @property
    def state(self):
        if not self.completed:
            return NOT_RUN
        if self.passed:
            return PASSED
        return WARNING if self.warn_on_fail else FAILED

    @property
    def error_count(self):
        return len(self.error_objects) + sum(len(v[1]) for v in self.error_elements.values())

    def detail_lines(self):
        """Human-readable per-error lines for the details popup."""
        lines = list(self.error_objects)
        for name, (domain, indices) in self.error_elements.items():
            lines.append(f"{name}  —  {len(indices)} {domain.lower()}(s)")
        return lines

    # --- selection ---
    def select(self, context):
        if self.error_elements:
            self._select_elements(context)
        else:
            self._select_objects(context)

    def _to_object_mode(self, context):
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

    def _select_objects(self, context):
        self._to_object_mode(context)
        bpy.ops.object.select_all(action='DESELECT')
        last = None
        for n in self.error_objects:
            ob = context.scene.objects.get(n)
            if ob:
                ob.select_set(True)
                last = ob
        if last:
            context.view_layer.objects.active = last

    def _select_elements(self, context):
        self._to_object_mode(context)
        bpy.ops.object.select_all(action='DESELECT')

        names = list(self.error_elements)
        active = None
        domain = 'FACE'
        for n in names:
            ob = context.scene.objects.get(n)
            if ob:
                ob.select_set(True)
                active = ob
                domain = self.error_elements[n][0]
        if not active:
            return

        context.view_layer.objects.active = active
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type=domain)
        bpy.ops.mesh.select_all(action='DESELECT')

        for n in names:
            ob = context.scene.objects.get(n)
            if not ob or ob.mode != 'EDIT':
                continue
            dom, indices = self.error_elements[n]
            bm = bmesh.from_edit_mesh(ob.data)
            seq = {'VERT': bm.verts, 'EDGE': bm.edges, 'FACE': bm.faces}[dom]
            seq.ensure_lookup_table()
            wanted = set(indices)
            for el in seq:
                if el.index in wanted:
                    el.select_set(True)
            bmesh.update_edit_mesh(ob.data)


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------
class DuplicateNamesCheck(ValidationCheck):
    id = "duplicate_names"
    name = "Duplicate names"
    description = "Objects/meshes with a .001-style suffix (name clash on UE import)"
    warn_on_fail = True
    can_select = True

    def execute(self, context):
        for ob in self.targets(context):
            if _SUFFIX.search(ob.name) or _SUFFIX.search(ob.data.name):
                self.error_objects.append(ob.name)
        return not self.error_objects


class UnappliedTransformCheck(ValidationCheck):
    id = "unapplied_transform"
    name = "Unapplied transforms"
    description = "Non-1 scale or non-zero rotation — bakes wrong into the FBX"
    warn_on_fail = True
    can_select = True
    can_fix = True
    can_retry_on_fix = True

    def execute(self, context):
        for ob in self.targets(context):
            bad_scale = any(abs(v - 1.0) > 1e-4 for v in ob.scale)
            bad_rot = any(abs(a) > 1e-4 for a in ob.rotation_euler)
            if bad_scale or bad_rot:
                self.error_objects.append(ob.name)
        return not self.error_objects

    def fix(self, context):
        self._select_objects(context)
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


class MissingUVCheck(ValidationCheck):
    id = "missing_uv"
    name = "Missing UVs"
    description = "Meshes with faces but no UV map (no lightmaps/texturing in UE)"
    can_select = True

    def execute(self, context):
        for ob in self.targets(context):
            if len(ob.data.polygons) > 0 and len(ob.data.uv_layers) == 0:
                self.error_objects.append(ob.name)
        return not self.error_objects


class NgonCheck(ValidationCheck):
    id = "ngons"
    name = "N-gons"
    description = "Faces with more than 4 sides (UE triangulates; can shade badly)"
    warn_on_fail = True
    can_select = True
    can_fix = True
    can_retry_on_fix = True

    def execute(self, context):
        for ob in self.targets(context):
            ngons = [p.index for p in ob.data.polygons if p.loop_total > 4]
            if ngons:
                self.error_elements[ob.name] = ('FACE', ngons)
        return not self.error_elements

    def fix(self, context):
        self._select_elements(context)
        bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
        bpy.ops.object.mode_set(mode='OBJECT')


class LooseGeometryCheck(ValidationCheck):
    id = "loose_geometry"
    name = "Loose geometry"
    description = "Vertices/edges not connected to any face (stray geo in UE)"
    warn_on_fail = True
    can_select = True
    can_fix = True
    can_retry_on_fix = True

    def execute(self, context):
        for ob in self.targets(context):
            me = ob.data
            used = set()
            for p in me.polygons:
                used.update(p.vertices)
            loose = [v.index for v in me.vertices if v.index not in used]
            if loose:
                self.error_elements[ob.name] = ('VERT', loose)
        return not self.error_elements

    def fix(self, context):
        self._select_elements(context)
        # delete_loose acts on the whole mesh, clearing every stray vert/edge.
        bpy.ops.mesh.delete_loose(use_verts=True, use_edges=True, use_faces=False)
        bpy.ops.object.mode_set(mode='OBJECT')


class EmptyMeshCheck(ValidationCheck):
    id = "empty_mesh"
    name = "Empty meshes"
    description = "Mesh objects with no faces"
    can_select = True

    def execute(self, context):
        for ob in self.targets(context):
            if len(ob.data.polygons) == 0:
                self.error_objects.append(ob.name)
        return not self.error_objects


class NonManifoldCheck(ValidationCheck):
    id = "non_manifold"
    name = "Non-manifold"
    description = "Non-manifold edges: open boundaries, wire, or >2 faces (matches the Mesh Check overlay)"
    warn_on_fail = True
    can_select = True

    def execute(self, context):
        for ob in self.targets(context):
            bm = bmesh.new()
            bm.from_mesh(ob.data)
            # Same definition as the overlay: boundary (1 face), wire (0) and
            # multi-face (>2) edges all report is_manifold == False.
            bad = [e.index for e in bm.edges if not e.is_manifold]
            bm.free()
            if bad:
                self.error_elements[ob.name] = ('EDGE', bad)
        return not self.error_elements


class DegenerateFaceCheck(ValidationCheck):
    id = "degenerate_faces"
    name = "Degenerate faces"
    description = "Zero-area faces — become broken triangles on UE import"
    warn_on_fail = True
    can_select = True
    can_fix = True
    can_retry_on_fix = True

    def execute(self, context):
        for ob in self.targets(context):
            bad = [p.index for p in ob.data.polygons if p.area < 1e-8]
            if bad:
                self.error_elements[ob.name] = ('FACE', bad)
        return not self.error_elements

    def fix(self, context):
        self._select_elements(context)
        bpy.ops.mesh.dissolve_degenerate()
        bpy.ops.object.mode_set(mode='OBJECT')


class EmptyMaterialCheck(ValidationCheck):
    id = "empty_material"
    name = "Material missing"
    description = "Objects with no material or an empty material slot (gray in UE)"
    warn_on_fail = True
    can_select = True

    def execute(self, context):
        for ob in self.targets(context):
            slots = ob.material_slots
            if len(slots) == 0 or any(s.material is None for s in slots):
                self.error_objects.append(ob.name)
        return not self.error_objects


class NamingConventionCheck(ValidationCheck):
    id = "naming_convention"
    name = "Naming (SM_ prefix)"
    description = "Static-mesh objects should start with SM_ (edit PREFIX to change)"
    warn_on_fail = True
    can_select = True

    PREFIX = "SM_"

    def execute(self, context):
        for ob in self.targets(context):
            if not ob.name.startswith(self.PREFIX):
                self.error_objects.append(ob.name)
        return not self.error_objects


ALL_CHECKS = (
    DuplicateNamesCheck,
    NamingConventionCheck,
    UnappliedTransformCheck,
    MissingUVCheck,
    EmptyMaterialCheck,
    NgonCheck,
    DegenerateFaceCheck,
    NonManifoldCheck,
    LooseGeometryCheck,
    EmptyMeshCheck,
)

# Singleton instances hold results between an operator run and the panel draw.
_INSTANCES = None


def get_checks():
    global _INSTANCES
    if _INSTANCES is None:
        _INSTANCES = [cls() for cls in ALL_CHECKS]
    return _INSTANCES


def get_check(check_id):
    return next((c for c in get_checks() if c.id == check_id), None)


def reset_checks():
    for c in get_checks():
        c.reset()


def worst_state():
    """Aggregate: FAILED > WARNING > PASSED > NOT_RUN."""
    order = {FAILED: 3, WARNING: 2, PASSED: 1, NOT_RUN: 0}
    return max((c.state for c in get_checks()), key=lambda s: order[s], default=NOT_RUN)
